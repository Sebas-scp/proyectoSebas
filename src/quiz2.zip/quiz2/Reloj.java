/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quiz2;

/**
 *
 * @author usuario
 */
public class Reloj 
{
    public void setAlarm(int horas, int minutos)
    {
        
    }
    
    public int getHora()
    {
        
    }
    
    public int getMin()
}
