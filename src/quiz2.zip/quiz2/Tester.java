package quiz2;

/**
 *
 * @author carlosandres.mendez
 */
public class Tester {
    public static void main(String[] args) {
        EquipoSonidoControlador c = new EquipoSonidoControlador();
        c.iniciar();
    }
}
